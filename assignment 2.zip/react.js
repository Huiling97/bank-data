const fetch = require('node-fetch');
import React from 'react';

class myComponent extends React.Component {
    componentDidMount() {
        const apiUrl = 'https://localhost:3000';
        fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => console.log('This is your data', data));
    }
    render() {
        return <h1>my Component has mounted, check the browser 'console' </h1>;
    }
}

export default myComponent;